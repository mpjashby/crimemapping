NOTE ON THE BOSTON MURDERS ZIP FILE

This file previously contained a single file buried inside several
sub-directories. To make the file easier to read, I have removed the
sub-directories and put the single data file boston_murders.csv in the top (and
now only) level of the zip file.
